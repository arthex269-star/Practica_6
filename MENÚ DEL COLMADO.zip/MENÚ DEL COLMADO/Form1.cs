﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MENÚ_DEL_COLMADO
{
    public partial class Form1 : Form
    {
       private Dictionary<string, decimal> productos =
       new Dictionary<string, decimal>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Productos disponibles
            productos.Add("Arroz", 35.00m);
            productos.Add("Habichuelas", 75.00m);
            productos.Add("Aceite", 150.00m);
            productos.Add("Azúcar", 40.00m);
            productos.Add("Leche", 65.00m);
            productos.Add("Pan", 10.00m);
            productos.Add("Huevos", 12.00m);
            productos.Add("Refresco", 70.00m);
            productos.Add("Agua", 25.00m);
            productos.Add("Café", 120.00m);

            // Agregar los productos al ComboBox
            foreach (string producto in productos.Keys)
            {
                cmbProductos.Items.Add(producto);
            }

            cmbProductos.SelectedIndex = -1;
            cmbProductos.Text = "Seleccione un producto";

            rdbEfectivo.Checked = true;

            lblPrecio.Text = "Precio: RD$ 0.00";
            lblTotal.Text = "Total: RD$ 0.00";
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            cmbProductos.SelectedIndex = -1;
            cmbProductos.Text = "Seleccione un producto";

            txtCantidad.Clear();

            rdbEfectivo.Checked = true;

            lblPrecio.Text = "Precio: RD$ 0.00";
            lblTotal.Text = "Total: RD$ 0.00";

            cmbProductos.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (cmbProductos.SelectedItem == null)
            {
                MessageBox.Show(
                    "Seleccione un producto.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                cmbProductos.Focus();
                return;
            }

            int cantidad;

            if (!int.TryParse(txtCantidad.Text, out cantidad) ||
                cantidad <= 0)
            {
                MessageBox.Show(
                    "Introduzca una cantidad válida.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtCantidad.Focus();
                txtCantidad.SelectAll();
                return;
            }

            string productoSeleccionado =
                cmbProductos.SelectedItem.ToString();

            decimal precio = productos[productoSeleccionado];
            decimal subtotal = precio * cantidad;
            decimal recargo = 0;
            string formaPago = "";

            if (rdbEfectivo.Checked)
            {
                formaPago = "Efectivo";
            }
            else if (rdbTarjeta.Checked)
            {
                formaPago = "Tarjeta";

                // Recargo del 5 % por tarjeta
                recargo = subtotal * 0.05m;
            }
            else if (rdbTransferencia.Checked)
            {
                formaPago = "Transferencia";
            }
            else
            {
                MessageBox.Show(
                    "Seleccione una forma de pago.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            decimal total = subtotal + recargo;

            lblTotal.Text = "Total: RD$ " +
                            total.ToString("N2");

            MessageBox.Show(
                "Producto: " + productoSeleccionado +
                "\nPrecio: RD$ " + precio.ToString("N2") +
                "\nCantidad: " + cantidad +
                "\nSubtotal: RD$ " + subtotal.ToString("N2") +
                "\nForma de pago: " + formaPago +
                "\nRecargo: RD$ " + recargo.ToString("N2") +
                "\nTotal: RD$ " + total.ToString("N2"),
                "Resumen de compra",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void rdbTransferencia_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdbTarjeta_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdbEfectivo_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void grpPago_Enter(object sender, EventArgs e)
        {

        }


        private void lblCantidad_Click(object sender, EventArgs e)
        {

        }

        private void lblPrecio_Click(object sender, EventArgs e)
        {

        }

        private void cmbProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProductos.SelectedItem != null)
            {
                string productoSeleccionado =
                    cmbProductos.SelectedItem.ToString();

                decimal precio = productos[productoSeleccionado];

                lblPrecio.Text = "Precio: RD$ " +
                                 precio.ToString("N2");
            }
        }

        private void lblProducto_Click(object sender, EventArgs e)
        {

        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }

        private void txtCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtCantidad_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
