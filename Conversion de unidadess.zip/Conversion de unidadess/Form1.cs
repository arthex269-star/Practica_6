namespace Conversion_de_unidadess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            cmbTipo.Items.Add("Kilómetros a Millas");
            cmbTipo.Items.Add("Millas a Kilómetros");
            cmbTipo.Items.Add("Celsius a Fahrenheit");
            cmbTipo.Items.Add("Fahrenheit a Celsius");

            cmbTipo.SelectedIndex = 0;
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            double valor;
            double resultado;

            if (!double.TryParse(txtValor.Text, out valor))
            {
                MessageBox.Show("Ingrese un número válido.");
                return;
            }

            switch (cmbTipo.SelectedItem.ToString())
            {
                case "Kilómetros a Millas":
                    resultado = valor * 0.621371;
                    lblResultado.Text = resultado.ToString("0.00") + " Millas";
                    break;

                case "Millas a Kilómetros":
                    resultado = valor / 0.621371;
                    lblResultado.Text = resultado.ToString("0.00") + " Km";
                    break;

                case "Celsius a Fahrenheit":
                    resultado = (valor * 9 / 5) + 32;
                    lblResultado.Text = resultado.ToString("0.00") + " °F";
                    break;

                case "Fahrenheit a Celsius":
                    resultado = (valor - 32) * 5 / 9;
                    lblResultado.Text = resultado.ToString("0.00") + " °C";
                    break;
            }
        }
    }
}
