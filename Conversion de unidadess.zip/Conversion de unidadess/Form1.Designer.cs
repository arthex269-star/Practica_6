﻿namespace Conversion_de_unidadess
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitulo = new Label();
            lblValor = new Label();
            txtValor = new TextBox();
            lblTipo = new Label();
            cmbTipo = new ComboBox();
            btnConvertir = new Button();
            lblResultadoTitulo = new Label();
            label1 = new Label();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(367, 37);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(203, 25);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Conversion de unidades";
            // 
            // lblValor
            // 
            lblValor.AutoSize = true;
            lblValor.Location = new Point(109, 82);
            lblValor.Name = "lblValor";
            lblValor.Size = new Size(133, 25);
            lblValor.TabIndex = 1;
            lblValor.Text = "Ingrese el Valor";
            // 
            // txtValor
            // 
            txtValor.Location = new Point(248, 82);
            txtValor.Name = "txtValor";
            txtValor.Size = new Size(306, 31);
            txtValor.TabIndex = 2;
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(111, 141);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(84, 25);
            lblTipo.TabIndex = 3;
            lblTipo.Text = "Convertir";
            // 
            // cmbTipo
            // 
            cmbTipo.FormattingEnabled = true;
            cmbTipo.Location = new Point(201, 141);
            cmbTipo.Name = "cmbTipo";
            cmbTipo.Size = new Size(206, 33);
            cmbTipo.TabIndex = 4;
            // 
            // btnConvertir
            // 
            btnConvertir.Location = new Point(110, 220);
            btnConvertir.Name = "btnConvertir";
            btnConvertir.Size = new Size(214, 38);
            btnConvertir.TabIndex = 5;
            btnConvertir.Text = "Convertir";
            btnConvertir.UseVisualStyleBackColor = true;
            btnConvertir.Click += btnConvertir_Click;
            // 
            // lblResultadoTitulo
            // 
            lblResultadoTitulo.AutoSize = true;
            lblResultadoTitulo.Location = new Point(111, 291);
            lblResultadoTitulo.Name = "lblResultadoTitulo";
            lblResultadoTitulo.Size = new Size(90, 25);
            lblResultadoTitulo.TabIndex = 6;
            lblResultadoTitulo.Text = "Resultado";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(182, 375);
            label1.Name = "label1";
            label1.Size = new Size(0, 25);
            label1.TabIndex = 7;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(109, 330);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(185, 25);
            lblResultado.TabIndex = 8;
            lblResultado.Text = "Resultado saldra aqui:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1038, 448);
            Controls.Add(lblResultado);
            Controls.Add(label1);
            Controls.Add(lblResultadoTitulo);
            Controls.Add(btnConvertir);
            Controls.Add(cmbTipo);
            Controls.Add(lblTipo);
            Controls.Add(txtValor);
            Controls.Add(lblValor);
            Controls.Add(lblTitulo);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitulo;
        private Label lblValor;
        private TextBox txtValor;
        private Label lblTipo;
        private ComboBox cmbTipo;
        private Button btnConvertir;
        private Label lblResultadoTitulo;
        private Label label1;
        private Label lblResultado;
    }
}
