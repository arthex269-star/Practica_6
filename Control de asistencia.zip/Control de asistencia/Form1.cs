﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Control_de_asistencia
{
    public partial class Form1 : Form
    {
        private List<string> estudiantesPresentes = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lstEstudiantes.Items.Add("Ana Martínez");
            lstEstudiantes.Items.Add("Carlos Pérez");
            lstEstudiantes.Items.Add("María Rodríguez");
            lstEstudiantes.Items.Add("José González");
            lstEstudiantes.Items.Add("Laura Sánchez");
            lstEstudiantes.Items.Add("Pedro Ramírez");
            lstEstudiantes.Items.Add("Sofía Hernández");

            // Seleccionar el primer estudiante
            if (lstEstudiantes.Items.Count > 0)
            {
                lstEstudiantes.SelectedIndex = 0;
            }

            lblTotal.Text = "Total presentes: 0";
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            // Verificar que haya un estudiante seleccionado
            if (lstEstudiantes.SelectedItem == null)
            {
                MessageBox.Show(
                    "Seleccione un estudiante.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            string estudianteSeleccionado =
                lstEstudiantes.SelectedItem.ToString();

            // Verificar que el estudiante esté marcado como presente
            if (!chkPresente.Checked)
            {
                MessageBox.Show(
                    "Debe marcar la casilla Presente.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            // Evitar registrar el mismo estudiante dos veces
            if (estudiantesPresentes.Contains(estudianteSeleccionado))
            {
                MessageBox.Show(
                    "Este estudiante ya fue registrado como presente.",
                    "Registro duplicado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                return;
            }

            // Agregar estudiante a la lista
            estudiantesPresentes.Add(estudianteSeleccionado);

            MessageBox.Show(
                estudianteSeleccionado + " fue registrado como presente.",
                "Asistencia registrada",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );

            // Desmarcar el CheckBox
            chkPresente.Checked = false;

            // Actualizar cantidad
            lblTotal.Text = "Total presentes: " +
            estudiantesPresentes.Count;
        }

        private void btnResumen_Click(object sender, EventArgs e)
        {
            // Limpiar el resumen anterior
            lstResumen.Items.Clear();

            if (estudiantesPresentes.Count == 0)
            {
                MessageBox.Show(
                    "Todavía no se han registrado estudiantes presentes.",
                    "Resumen",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                lblTotal.Text = "Total presentes: 0";
                return;
            }

            // Mostrar los estudiantes registrados
            foreach (string estudiante in estudiantesPresentes)
            {
                lstResumen.Items.Add(estudiante);
            }

            lblTotal.Text = "Total presentes: " +
            estudiantesPresentes.Count;
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            DialogResult respuesta = MessageBox.Show(
               "¿Desea eliminar todos los registros de asistencia?",
               "Confirmar",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );

            if (respuesta == DialogResult.Yes)
            {
                estudiantesPresentes.Clear();
                lstResumen.Items.Clear();
                chkPresente.Checked = false;

                if (lstEstudiantes.Items.Count > 0)
                {
                    lstEstudiantes.SelectedIndex = 0;
                }

                lblTotal.Text = "Total presentes: 0";

                MessageBox.Show(
                    "Los registros fueron eliminados.",
                    "Información",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }
    }
}

