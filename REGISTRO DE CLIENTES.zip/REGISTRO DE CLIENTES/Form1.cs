﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REGISTRO_DE_CLIENTES
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblTotal.Text = "Total de clientes: 0";
            txtNombre.Focus();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string correo = txtCorreo.Text.Trim();

            // Validar nombre
            if (nombre == "")
            {
                MessageBox.Show(
                    "Debe escribir el nombre del cliente.",
                    "Campo obligatorio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtNombre.Focus();
                return;
            }

            if (nombre.Length < 3)
            {
                MessageBox.Show(
                    "El nombre debe tener al menos 3 caracteres.",
                    "Nombre inválido",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtNombre.Focus();
                txtNombre.SelectAll();
                return;
            }

            // Validar teléfono
            if (telefono == "")
            {
                MessageBox.Show(
                    "Debe escribir el teléfono del cliente.",
                    "Campo obligatorio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtTelefono.Focus();
                return;
            }

            if (!TelefonoValido(telefono))
            {
                MessageBox.Show(
                    "Escriba un teléfono válido.\nEjemplo: 809-555-1234",
                    "Teléfono inválido",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtTelefono.Focus();
                txtTelefono.SelectAll();
                return;
            }

            // Validar correo
            if (correo == "")
            {
                MessageBox.Show(
                    "Debe escribir el correo electrónico.",
                    "Campo obligatorio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtCorreo.Focus();
                return;
            }

            if (!CorreoValido(correo))
            {
                MessageBox.Show(
                    "Escriba un correo electrónico válido.\nEjemplo: cliente@gmail.com",
                    "Correo inválido",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                txtCorreo.Focus();
                txtCorreo.SelectAll();
                return;
            }

            // Evitar clientes repetidos por correo
            foreach (object elemento in lstClientes.Items)
            {
                string clienteRegistrado = elemento.ToString();

                if (clienteRegistrado.Contains(correo))
                {
                    MessageBox.Show(
                        "Ya existe un cliente registrado con este correo.",
                        "Cliente duplicado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                    txtCorreo.Focus();
                    txtCorreo.SelectAll();
                    return;
                }
            }

            // Agregar cliente al ListBox
            string cliente =
                nombre + " | " +
                telefono + " | " +
                correo;

            lstClientes.Items.Add(cliente);

            lblTotal.Text =
                "Total de clientes: " + lstClientes.Items.Count;

            MessageBox.Show(
                "Cliente registrado correctamente.",
                "Registro completado",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );

            LimpiarCampos();
        }

        private bool TelefonoValido(string telefono)
        {
            // Permite formatos como:
            // 8095551234
            // 809-555-1234
            // (809) 555-1234

            string patron =
                @"^(\(\d{3}\)\s?|\d{3}[-\s]?)\d{3}[-\s]?\d{4}$";

            return Regex.IsMatch(telefono, patron);
        }

        private bool CorreoValido(string correo)
        {
            string patron =
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            return Regex.IsMatch(correo, patron);
        }
        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();

            txtNombre.Focus();
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            if (lstClientes.SelectedItem == null)
            {
                MessageBox.Show(
                    "Seleccione un cliente de la lista.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Desea eliminar el cliente seleccionado?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta == DialogResult.Yes)
            {
                lstClientes.Items.Remove(
                    lstClientes.SelectedItem
                );

                lblTotal.Text =
                    "Total de clientes: " +
                    lstClientes.Items.Count;
            }
        }

        private void btnEliminar_Click_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
    txtTelefono.Clear();
    txtCorreo.Clear();

    txtNombre.Focus();
        }

        private void Limpiar_all_Click(object sender, EventArgs e)
        {
            if (lstClientes.Items.Count == 0)
            {
                MessageBox.Show(
                    "No hay clientes registrados para eliminar.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Está seguro de eliminar todos los clientes registrados?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta == DialogResult.Yes)
            {
                lstClientes.Items.Clear();

                lblTotal.Text = "Total de clientes: 0";

                MessageBox.Show(
                    "Todos los clientes fueron eliminados correctamente.",
                    "Proceso completado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }

        private void Eliminar_sel_Click(object sender, EventArgs e)
        {
            if (lstClientes.SelectedItem == null)
            {
                MessageBox.Show(
                    "Seleccione un cliente de la lista.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Desea eliminar el cliente seleccionado?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta == DialogResult.Yes)
            {
                lstClientes.Items.Remove(lstClientes.SelectedItem);

                lblTotal.Text =
                    "Total de clientes: " + lstClientes.Items.Count;

                MessageBox.Show(
                    "Cliente eliminado correctamente.",
                    "Eliminación",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }
    }
}